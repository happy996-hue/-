#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include "serialport.h"
#include "wavewidget.h"
#include <QLabel>
#include <QColor>

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    MainWidget(QWidget *parent = nullptr);
    ~MainWidget();
    WaveWidget *ecg, *spo, *ibp;
    QLabel *ecgLabel, *spoLabel, *ibpLabel;
private:
    SerialPort *com_;

};
#endif // MAINWIDGET_H

#include "wavewidget.h"
#include <QTimer>
#include <QPainter>
#include <QColor>

WaveWidget::WaveWidget(QWidget *parent) : QWidget(parent)
{

}

WaveWidget::WaveWidget(QColor color, QWidget *parent) : QWidget(parent)
{
//    resize(600, 150);
    color_ = color;
    pix_ = new QPixmap(width(), height());
    pix_->fill(Qt::black);
}
void WaveWidget::ecgrefreshPixmap(int data)
{
    if(!initecg)
    {
        lecg = data;
        initecg = 1;
    }
    //pix_->scaled(width(), height());
    //*pix_ = pix_->scaled(size());
    QPainter painter(pix_);
    painter.setPen(QPen(color_, 2));

    painter.save();
    painter.setPen(Qt::black);
    painter.drawLine((index+9)%width(), 0, (index+9)%width(), pix_->height());
    painter.drawLine((index+10)%width(), 0, (index+10)%width(), pix_->height());
    painter.restore();

    index += 1;
    if(index > pix_->width())
    {
        index = 0;
    }

    QPoint lineStart, lineEnd;
    lineStart.setX(index-1);
    lineEnd.setX(index);
    lineStart.setY(round((double)pix_->height()/2 - ((double)lecg-2048)/600*pix_->height()/2));
    lineEnd.setY(round((double)pix_->height()/2 - ((double)data-2048)/600*pix_->height()/2));
    painter.drawLine(lineStart, lineEnd);
    lecg = data;
    update();

}

void WaveWidget::sporefreshPixmap(int data)
{
    //pix_->scaled(width(), height());
    //*pix_ = pix_->scaled(size());
    if(!initecg)
    {
        lecg = data;
        initecg = 1;
    }
    QPainter painter(pix_);
    painter.setPen(QPen(color_, 2));

    painter.save();
    painter.setPen(Qt::black);
    painter.drawLine((index+9)%width(), 0, (index+9)%width(), pix_->height());
    painter.drawLine((index+10)%width(), 0, (index+10)%width(), pix_->height());
    painter.restore();

    index += 1;
    if(index > pix_->width())
    {
        index = 0;
    }

    QPoint lineStart, lineEnd;
    lineStart.setX(index-1);
    lineEnd.setX(index);
    lineStart.setY(round((double)pix_->height()/2 - ((double)lecg)/100*pix_->height()/2)+20);
    lineEnd.setY(round((double)pix_->height()/2 - ((double)data)/100*pix_->height()/2)+20);
    painter.drawLine(lineStart, lineEnd);
    lecg = data;
    update();

}

void WaveWidget::ibprefreshPixmap(int data)
{
    //pix_->scaled(width(), height());
    //*pix_ = pix_->scaled(size());
    if(!initibp)
    {
        libp = data;
        initibp = 1;
    }
    QPainter painter(pix_);
    painter.setPen(QPen(color_, 2));

    painter.save();
    painter.setPen(Qt::black);
    painter.drawLine((index+9)%width(), 0, (index+9)%width(), pix_->height());
    painter.drawLine((index+10)%width(), 0, (index+10)%width(), pix_->height());
    painter.restore();

    index += 1;
    if(index > pix_->width())
    {
        index = 0;
    }

    QPoint lineStart, lineEnd;
    lineStart.setX(index-1);
    lineEnd.setX(index);
    lineStart.setY(round((double)pix_->height()/2 - ((double)libp)/20*pix_->height()/2)+80);
    lineEnd.setY(round((double)pix_->height()/2 - ((double)data)/20*pix_->height()/2)+80);
    painter.drawLine(lineStart, lineEnd);
    libp = data;
    update();

}

void WaveWidget::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.drawPixmap(0, 0, pix_->width(), pix_->height(), *pix_);
}

void WaveWidget::resizeEvent(QResizeEvent *event)
{
    *pix_ = pix_->scaled(size());
}

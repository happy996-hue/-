#include "mainwidget.h"
#include "serialport.h"
#include <QVBoxLayout>

MainWidget::MainWidget(QWidget *parent)
    : QWidget(parent)
{

    //resize(600, 450);
//    setWindowFlag(Qt::FramelessWindowHint);
    setStyleSheet("background-color:black");
    ecgLabel = new QLabel("ECG");
    spoLabel = new QLabel("SPO");
    ibpLabel = new QLabel("IBP");
    ecgLabel->setStyleSheet("color:white; background-color:red");
    spoLabel->setStyleSheet("color:white; background-color:red");
    ibpLabel->setStyleSheet("color:white; background-color:red");
    ecg = new WaveWidget(QColor(255, 0, 0), this);
    spo = new WaveWidget(QColor(0, 255, 0), this);
    ibp = new WaveWidget(QColor(0, 0, 255), this);
    QVBoxLayout *layout = new QVBoxLayout;  //把这个layout放在外层layout中
    QVBoxLayout *layout1 = new QVBoxLayout;
    QVBoxLayout *layout2 = new QVBoxLayout;
    QVBoxLayout *layout3 = new QVBoxLayout;
    layout1->addWidget(ecgLabel);
    layout1->addWidget(ecg);
    layout2->addWidget(spoLabel);
    layout2->addWidget(spo);
    layout3->addWidget(ibpLabel);
    layout3->addWidget(ibp);
    layout->addLayout(layout1);
    layout->addLayout(layout2);
    layout->addLayout(layout3);
    layout1->setStretch(1, 5);
    layout2->setStretch(1, 5);
    layout3->setStretch(1, 5);
    setLayout(layout);
    com_ = new SerialPort(this);
    connect(com_, &SerialPort::ecgr,
            ecg, &WaveWidget::ecgrefreshPixmap);
    connect(com_, &SerialPort::spor,
            spo, &WaveWidget::sporefreshPixmap);
    connect(com_, &SerialPort::ibpr,
            ibp, &WaveWidget::ibprefreshPixmap);

}

MainWidget::~MainWidget()
{
}


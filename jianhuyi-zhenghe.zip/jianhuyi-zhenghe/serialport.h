#ifndef QWIDGETSERIALRX_H
#define QWIDGETSERIALRX_H

#include <QWidget>
#include <QObject>
#include <QtSerialPort/QSerialPortInfo>
#include <QtSerialPort/QSerialPort>
#include <QTimer>

class SerialPort : public QWidget
{
    Q_OBJECT
public:
    QSerialPort *com;
    char status = 0;
    char pkgDataCnt;
    char pkgDataHead;
    char pkgData[7];
    char pkgDataCrc;
    int ecg1, ecg2, ecg3, spo;

    explicit SerialPort(QWidget *parent = nullptr);

    int serialInit();
    void serialRx();
    void rxDataHandle(unsigned char data);

signals:
    void ecgr(int ecg);
    void spor(int spo);
    void ibpr(int ibp);

};

#endif // QWIDGETSERIALRX_H

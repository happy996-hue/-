#include "mainwindow.h"
#include "mainwidget.h"
#include <QApplication>
#include <QDebug>
#include <QPainter>
#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPen>
#include <QLabel>
#include <qmath.h>
#include <QBasicTimer>
#include <QPixmap>
#include<QSizePolicy>

const int ecgWave[] = {2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2008, 2016, 2016, 2016, 2024, 2032, 2048,
        2064, 2064, 2064, 2072, 2080, 2080, 2080, 2088, 2096, 2104,
        2112, 2112, 2112, 2112, 2112, 2112, 2104, 2096, 2088,
        2080, 2080, 2080, 2072, 2064, 2064, 2064, 2048, 2032, 2032,
        2032, 2016, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 1992, 1984, 1976,
        1968, 1960, 1952, 1944, 1936, 1944, 1952, 2016, 2080, 2136,
        2192, 2256, 2320, 2376, 2432, 2488, 2544, 2568, 2592, 2536,
        2480, 2424, 2368, 2304, 2240, 2184, 2128, 2072, 2016, 1968,
        1920, 1928, 1936, 1944, 1952, 1960, 1968, 1984, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2008, 2016, 2024, 2032, 2032,
        2032, 2048, 2064, 2064, 2064, 2072, 2080, 2088, 2096, 2104,
        2112, 2112, 2112, 2120, 2128, 2136, 2144, 2152, 2160, 2160,
        2160, 2160, 2160, 2168, 2176, 2176, 2176, 2184, 2192,
        2192, 2192, 2192, 2200, 2208, 2208, 2208, 2208, 2208, 2208,
        2208, 2200, 2192, 2192, 2192, 2184, 2176, 2176, 2176, 2168,
        2160, 2160, 2160, 2144, 2128, 2128, 2128, 2128, 2128, 2112,
        2096, 2088, 2080, 2072, 2064, 2064, 2064, 2048, 2032, 2024,
        2016, 2016, 2016, 2008, 2000, 2000, 2000, 2000, 2000,
        2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000};

class QWidgetDraw: public QWidget
{
public:
    int ecgDataIndex;
    qreal index;
    qreal range;
    QPixmap *pixmap;
    QWidgetDraw(QWidget *parent=0):QWidget(parent)
    {
        QBasicTimer *timer =new QBasicTimer();
        timer->start(10,this);
        pixmap = new QPixmap(this->width(),this->height());//创建界面等大的新界面
               pixmap ->fill(Qt::black);//设置背景黑色

        index =0;//当前水平方向数据更新
        ecgDataIndex =0;//圆周角度
    }
    virtual void timerEvent(QTimerEvent *event)
    {
        qDebug()<<"timerEvent";
        drawWaveToPixmap();
        this->update();
    }
    void drawWaveToPixmap()
    {
        QPainter pixPainter;
        pixPainter.begin(this->pixmap);
        drawEcgWave(&pixPainter);
        pixPainter.end();
    }
    virtual void paintEvent(QPaintEvent *event)
    {
        QPainter *qpaint =new QPainter;
        qpaint->begin(this);
        qpaint->resetTransform();
        qpaint->drawPixmap(0,0,*pixmap);
        qpaint->resetTransform();
        qpaint->end();
    }
    void drawEcgWave(QPainter *qpaint)
    {
        QPen *pen =new QPen();
        pen->setWidth(2);
        pen->setColor(QColor("#228B22"));
        qpaint->setPen(*pen);
        //更新绘图参数，水平方向循环绘图
        index =index+1;
        if(index>width())
            index =0;//擦除当前点的位置，去除冲激值
        //擦除当前列
        qpaint->save();//保持当前配置
        pen->setColor(Qt::black);//画笔颜色
        qpaint->setPen(*pen);
        qpaint->drawLine(index,0,index,height());
        qpaint->restore();//还原当前配置

        qreal height =this->height();
        QPoint lineStart;
        QPoint lineEnd;

        lineStart.setX(index-1);//初值开始
        lineEnd.setX(index);

        qreal value =ecgWave[ecgDataIndex];
        int y =round(height/2-((value-2048)/600)*height/2);
        qDebug()<<y;
        lineStart.setY(y);
        ecgDataIndex =ecgDataIndex+5;
        if (ecgDataIndex>=sizeof(ecgWave)/sizeof(int))
            ecgDataIndex=0;
        value =ecgWave[ecgDataIndex];
        y =round(height/2-((value-2048)/600)*height/2);
        lineEnd.setY(y);
        qpaint->drawLine(lineStart,lineEnd);
    }
};

class Ecgwave: public QWidget
{
public:
    Ecgwave(QWidget *parent=0):QWidget(parent)
    {
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setStyleSheet("background-color:black");

    QLabel *title =new QLabel ("ECGII     x1");
    title->setStyleSheet("color:white");
    QWidgetDraw *waveWin =new QWidgetDraw();
    QVBoxLayout *layout =new QVBoxLayout();

    layout->addWidget(title);
    layout->addWidget(waveWin);
    layout->setStretch(0,1);
    layout->setStretch(1,5);
    this->setLayout(layout);
    }
};

//第二个波形
class Spowave: public QWidget
{
public:
    Spowave(QWidget *parent=0):QWidget(parent)
    {
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setStyleSheet("background-color:black");

    QLabel *title =new QLabel ("SPO2");
    title->setStyleSheet("color:white");
    QWidgetDraw *waveWin =new QWidgetDraw();//调用波形图
    QVBoxLayout *layout =new QVBoxLayout();

    layout->addWidget(title);
    layout->addWidget(waveWin);
    layout->setStretch(0,1);
    layout->setStretch(1,5);
    this->setLayout(layout);
    }
};
class reswave: public QWidget
{
public:
    reswave(QWidget *parent=0):QWidget(parent)
    {
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setStyleSheet("background-color:black");

    QLabel *title =new QLabel ("RESP     x1");
    title->setStyleSheet("color:white");
    QWidgetDraw *waveWin =new QWidgetDraw();
    QVBoxLayout *layout =new QVBoxLayout();

    layout->addWidget(title);
    layout->addWidget(waveWin);
    layout->setStretch(0,1);
    layout->setStretch(1,5);
    this->setLayout(layout);
    }
};


//右侧温度区域
class Hrwidget: public QWidget
{
public:
    Hrwidget(QWidget *parent=0):QWidget(parent)
    {
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setStyleSheet("background-color:black");
   // this->sizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum);
    //this->setMaximumSize(100,50);
    // this->setMinimumSize(80,40);
        QLabel*title = new QLabel("HR");
        title->setStyleSheet("background-color: rgb(49, 0, 0);color:white");
        QLabel*num = new QLabel("  80 ");
        num->setStyleSheet("color:green");
        QFont ft;
        ft.setPointSize(16);
        num->setFont(ft);
        QLabel*danwei = new QLabel("           bpm ");
        QFont ft2;
        ft2.setPointSize(10);
        title->setFont(ft2);
        danwei->setFont(ft2);
        danwei->setStyleSheet("color:green");
        QVBoxLayout*layout =new QVBoxLayout();


    layout->addWidget(title,1);
    layout->addWidget(danwei,1);
    layout->addWidget(num,4);

    this->setLayout(layout);
    }
};
class STwidget: public QWidget
{
public:
    STwidget(QWidget *parent=0):QWidget(parent)
    {
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setStyleSheet("background-color:black");

        QLabel*title = new QLabel("ST");
        title->setStyleSheet("background-color: rgb(49, 0, 0);color:white");
        QLabel*num1 = new QLabel("   ST1-?-   ");
        QLabel*num2 = new QLabel("   ST2-?-   ");
        QLabel*num3 = new QLabel("   PVCS-?-  ");
        num1->setStyleSheet("color:green");
        num2->setStyleSheet("color:green");
        num3->setStyleSheet("color:green");
        QFont ft;
        ft.setPointSize(12);
        num1->setFont(ft);
        num2->setFont(ft);
        num3->setFont(ft);
        QFont ft2;
        ft2.setPointSize(10);
        title->setFont(ft2);
        QVBoxLayout*layout =new QVBoxLayout();
        layout->addWidget(title,1);
        layout->addWidget(num1,1);
        layout->addWidget(num2,1);
        layout->addWidget(num3,1);
        this->setLayout(layout);
    }
};
class NIwidget: public QWidget
{
public:
    NIwidget(QWidget *parent=0):QWidget(parent)
    {
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setStyleSheet("background-color:black");
        QLabel*title = new QLabel("NIBP");
        title->setStyleSheet("background-color: rgb(49, 0, 0);color:white");
        QLabel*num = new QLabel("  -?-  / -?-  -?-");
        num->setStyleSheet("color: rgb(85, 0, 255);");
        QFont ft;
        ft.setPointSize(16);
        num->setFont(ft);
        QLabel*danwei = new QLabel("      00.00.00        mmHg");
        danwei->setStyleSheet("color: rgb(85, 0, 255);");
        QVBoxLayout*layout =new QVBoxLayout();


    layout->addWidget(title,1);
    layout->addWidget(danwei,1);
    layout->addWidget(num,2);
    this->setLayout(layout);
    }
};
class SPOwidget: public QWidget
{
public:
    SPOwidget(QWidget *parent=0):QWidget(parent)
    {
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setStyleSheet("background-color:black");
        QLabel*title = new QLabel("Spo2");
        title->setStyleSheet("background-color: rgb(49, 0, 0);color:white");
        QLabel*num1 = new QLabel("  98   %");
        num1->setStyleSheet("color: rgb(255, 0, 0);");
        QLabel*num2 = new QLabel("       84   bpm");
        num2->setStyleSheet("color: rgb(255, 0, 0);");
        QFont ft;
        ft.setPointSize(16);
        num1->setFont(ft);

        QFont ft2;
        ft2.setPointSize(10);
        num2->setFont(ft2);
        title->setFont(ft2);
        QVBoxLayout*layout =new QVBoxLayout();

    layout->addWidget(title,1);
    layout->addWidget(num1,4);
    layout->addWidget(num2,3);
    this->setLayout(layout);
    }
};
class TEMwidget: public QWidget
{
public:
    TEMwidget(QWidget *parent=0):QWidget(parent)
    {
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setStyleSheet("background-color:black");
        QLabel*title = new QLabel("TEMP");
        title->setStyleSheet("background-color: rgb(49, 0, 0);color:white");
        QLabel*num = new QLabel("                ℃");
        num->setStyleSheet("color: rgb(255, 0, 255);");
        QLabel*num1 = new QLabel("T1-?-");
        num1->setStyleSheet("color: rgb(255, 0, 255);");
        QLabel*num2 = new QLabel("           TD-?-");
        num2->setStyleSheet("color: rgb(255, 0, 255);");
        QLabel*num3 = new QLabel("T2-?-");
        num3->setStyleSheet("color: rgb(255, 0, 255);");
        QFont ft;
        ft.setPointSize(12);
        num->setFont(ft);
        num1->setFont(ft);
        num2->setFont(ft);
        num3->setFont(ft);
        QFont ft1;
        ft1.setPointSize(10);
        title->setFont(ft);
         QVBoxLayout*layout =new QVBoxLayout();



    layout->addWidget(title,1);
    layout->addWidget(num, 1);
    layout->addWidget(num1,1);
    layout->addWidget(num2,1);
    layout->addWidget(num3,1);
    this->setLayout(layout);
    }
};
class RESwidget: public QWidget
{
public:
    RESwidget(QWidget *parent=0):QWidget(parent)
    {
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setStyleSheet("background-color:black");
        QLabel*title = new QLabel("RESP");
        title->setStyleSheet("background-color: rgb(49, 0, 0);color:white");
        QLabel*num = new QLabel("         bpm");
        num->setStyleSheet("color: rgb(255, 170, 0);");
        QLabel*num1 = new QLabel(" 98");
        num1->setStyleSheet("color: rgb(255, 170, 0);");
        QFont ft;
        ft.setPointSize(16);
        num1->setFont(ft);
        QFont ft1;
        ft1.setPointSize(10);
        title->setFont(ft1);
        num->setFont(ft1);
        QVBoxLayout*layout =new QVBoxLayout();


    layout->addWidget(title,1);
    layout->addWidget(num,1);
    layout->addWidget(num1,3);
    this->setLayout(layout);
    }
};
class COwidget: public QWidget
{
public:
    COwidget(QWidget *parent=0):QWidget(parent)
    {
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setStyleSheet("background-color:black");
        QLabel*title = new QLabel("CO2");
        title->setStyleSheet("background-color: rgb(49, 0, 0);color:white");
        QLabel*num = new QLabel("                 mmHg");
        num->setStyleSheet("color: rgb(255, 170, 0);");
        QLabel*num1 = new QLabel("       -?-   ");
        num1->setStyleSheet("color: rgb(255, 170, 0);");
        QLabel*num2 = new QLabel("ins -?-    awrr -?-");
        num2->setStyleSheet("color: rgb(255, 170, 0);");
        QFont ft;
        ft.setPointSize(16);
        num1->setFont(ft);
        QFont ft1;
        ft1.setPointSize(10);
        title->setFont(ft1);
        num->setFont(ft1);
        num2->setFont(ft1);
        QVBoxLayout*layout =new QVBoxLayout();


    layout->addWidget(title,1);
    layout->addWidget(num,1);
    layout->addWidget(num1,2);
     layout->addWidget(num2,1);
    this->setLayout(layout);
    }
};


//标题
class mawidget: public QWidget
{
public:
    mawidget(QWidget *parent=0):QWidget(parent)
    {
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setStyleSheet("background-color:black");
        QLabel*title = new QLabel(" 设备xd001 备注001 ");
        title->setStyleSheet("background-color:black;color:white");
        QVBoxLayout*layout =new QVBoxLayout();


    layout->addWidget(title,1);
    this->setLayout(layout);
    }
};







int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
       //创建最上面的状态栏并配置颜色
       QWidget *widgetMainTitle = new mawidget();
       //widgetMainTitle->setStyleSheet("background-color: rgb(100,100,100)");//设置背景色为黑色


       //创建3个波形界面并配置颜色
//       QWidget *widgetWaveEcg = new Ecgwave();
//       widgetWaveEcg->setStyleSheet("background-color: black");//设置背景色
//       QWidget *widgetWavbeSpo2 = new Spowave();
//       widgetWavbeSpo2->setStyleSheet("background-color: black");//设置背景色
//       QWidget *widgetWaveResp = new reswave();
//       widgetWaveResp->setStyleSheet("background-color: black");//设置背景色

       //波形界面布局，三个波形界面采用垂直布局方式
//       QVBoxLayout *layoutWave = new QVBoxLayout();

//       layoutWave->addWidget(widgetWaveEcg);
//       layoutWave->addWidget(widgetWavbeSpo2);
//       layoutWave->addWidget(widgetWaveResp);
       //右侧温度等参数区域界面创建并配置颜色
       QWidget* widgetHr = new Hrwidget();
      // widgetHr->setStyleSheet("background-color: rgb(200,100,100)");
       QWidget* widgetSt = new STwidget();
       //widgetSt->setStyleSheet("background-color: rgb(100,100,200)");
       QWidget* widgetNibp = new NIwidget();
       //widgetNibp->setStyleSheet("background-color: rgb(100,200,100)");
       QWidget* widgetSpo2 = new SPOwidget();
       //widgetSpo2->setStyleSheet("background-color: rgb(200,100,200)");
       QWidget* widgetTemp = new TEMwidget();
       //widgetTemp->setStyleSheet("background-color: rgb(200,200,100)");
       QWidget* widgetResp = new RESwidget();
       //widgetResp->setStyleSheet("background-color: rgb(100,200,200)");
       QWidget* widgetCo2 = new COwidget();
       //widgetCo2->setStyleSheet("background-color: rgb(200,200,200)");

       //右侧部分界面布局，用水平布局+垂直布局方式完成
       QHBoxLayout* layoutTableLine1 = new QHBoxLayout();
       layoutTableLine1->addWidget(widgetHr);
       layoutTableLine1->addWidget(widgetSt);

       QHBoxLayout* layoutTableLine2 = new QHBoxLayout();
       layoutTableLine2->addWidget(widgetNibp);

       QHBoxLayout* layoutTableLine3 = new QHBoxLayout();
       layoutTableLine3->addWidget(widgetSpo2);
       layoutTableLine3->addWidget(widgetTemp);

       QHBoxLayout* layoutTableLine4 = new QHBoxLayout();
       layoutTableLine4->addWidget(widgetResp);
       layoutTableLine4->addWidget(widgetCo2);

       QVBoxLayout* layoutTable = new QVBoxLayout();
       layoutTable->addLayout(layoutTableLine1);
       layoutTable->addLayout(layoutTableLine2);
       layoutTable->addLayout(layoutTableLine3);
       layoutTable->addLayout(layoutTableLine4);

       //波形区域和参数显示区域水平布局
       QHBoxLayout* layoutDown = new QHBoxLayout();
       MainWidget* wid = new MainWidget();
       layoutDown->addWidget(wid);
       //layoutDown->addLayout(layoutWave);//
       layoutDown->addLayout(layoutTable);
       layoutDown->setStretch(0,2);
       layoutDown->setStretch(1,1);

       //主界面布局，采用1:10比例进行布局
       QVBoxLayout* layoutMain = new QVBoxLayout();
       layoutMain->addWidget(widgetMainTitle);
       layoutMain->addLayout(layoutDown);
       layoutMain->setStretch(0,1);
       layoutMain->setStretch(1,10);

       //主界面创建，并使用主界面布局器
       QWidget* widgetMain = new QWidget();
       widgetMain->resize(800,480);
       widgetMain->setWindowFlags (Qt::FramelessWindowHint);//隐藏标题栏
       widgetMain->setLayout(layoutMain);
       //widgetMain->show();//方法1


       widgetMain->setParent(&w);//方法2
       w.resize(800,480);

       QWidget*centralWidget = new QWidget(&w);
       centralWidget->setLayout(layoutMain);
     // centralWidget->setLayout(layoutWave);
       w.setCentralWidget(centralWidget);


       w.show();
       return a.exec();
}



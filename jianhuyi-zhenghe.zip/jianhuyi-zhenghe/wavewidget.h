#ifndef WAVEWIDGET_H
#define WAVEWIDGET_H

#include <QWidget>
#include <QPixmap>
#include <QColor>

class WaveWidget : public QWidget
{
    Q_OBJECT
public:
    explicit WaveWidget(QWidget *parent = nullptr);
    WaveWidget(QColor color, QWidget *parent = nullptr);

public slots:
    void ecgrefreshPixmap(int);
    void sporefreshPixmap(int);
    void ibprefreshPixmap(int);
protected:
    void paintEvent(QPaintEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;
private:
    QColor color_;
    QPixmap *pix_;
    int initecg {0}, initspo {0}, initibp {0};
    int lecg, lspo, libp;
    int index = 0;



signals:

};

#endif // WAVEWIDGET_H
